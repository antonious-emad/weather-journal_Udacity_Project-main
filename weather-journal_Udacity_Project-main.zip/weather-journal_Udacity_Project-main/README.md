# Weather-Journal App Project

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 
used:
HTML
CSS
JavaScript
Node.js

defined in package.jason
{Express
Cors
body-parser
nodemon}

Create account from site "api.openweathermap.org" to use APIs to fetch data of Weather 
API

## Instructions
to use it from your machine, just initate Server (using npmmon server.js or use npm start "as defined in Package.jason"
start URL "http://localhost:3000" then enter ZIP Code and what you feel then press Generate to get all needed data.
